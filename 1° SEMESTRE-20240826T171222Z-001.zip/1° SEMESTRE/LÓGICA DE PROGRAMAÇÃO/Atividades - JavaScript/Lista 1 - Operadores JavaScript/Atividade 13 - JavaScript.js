/*13) Uma feira de livros está fazendo promoção onde na compra de 3 livros, o(a)
comprador(a) ganha 15% de desconto. Criar um programa que receba os valores dos 3
livros e mostra na tela o total dos livros sem desconto e com desconto*/

const desconto = 15
var valorTotalComDesconto
var 