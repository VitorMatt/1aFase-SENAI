/*2) Faça um programa no qual o usuário digite dois números e mostre na tela a multiplicação desses números. */

let numeroUm
let numeroDois
let multiplicacaoNumeros

numeroUm = Number(prompt ('Digite o primeiro número: '))
numeroDois = Number(prompt ('Digite o segundo número: '))

multiplicacaoNumeros = numeroUm * numeroDois

alert ('Resultado: ' + multiplicacaoNumeros)