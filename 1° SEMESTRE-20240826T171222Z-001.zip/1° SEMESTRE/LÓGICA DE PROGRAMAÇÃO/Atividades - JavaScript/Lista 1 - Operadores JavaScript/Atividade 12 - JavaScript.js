/*12) Um programa de recomendação de livros baseado nos interesses do usuário. O sistema
deve solicitar ao usuário seus gêneros literários favoritos e, em seguida, sugerir uma lista de
livros que podem ser do seu interesse.*/

var generoFavoritoUsuario

generoFavoritoUsuario = prompt('Qual o seu gênero favorito?')

if (generoFavoritoUsuario=='terror' || generoFavoritoUsuario=='Terror' || generoFavoritoUsuario=='suspense' || generoFavoritoUsuario=='Suspense'){

alert ('Aqui estão alguuns livros recomendados para você:)\n\n')

}

else if (generoFavoritoUsuario=='romance' || generoFavoritoUsuario=='Romace'){

alert ('Aqui estão alguuns livros recomendados para você:)\n\n')

}

