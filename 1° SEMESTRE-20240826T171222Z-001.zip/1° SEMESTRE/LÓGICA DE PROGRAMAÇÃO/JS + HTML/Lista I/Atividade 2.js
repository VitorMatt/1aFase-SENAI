// 2) Criar uma mini-calculadora SIMPLES, com HTML e JS.
// A calculadora deve ter:

// -> Título, duas labels, dois inputs e quatro botões.
// -> Utilizar os 2 valores dos inputs para realizar a operação do botão clicado.
// -> Mostra o resultado em um alert.

let numeroUm = document.getElementById('numeroUm')
let numeroDois = document.getElementById('numeroDois')

function somaNumeros(){
    
    let somaNumeros = Number(numeroUm.value) + Number(numeroDois.value)
    somaNumeros = somaNumeros.toFixed(2)

    alert('O resultado é ' + somaNumeros)
}

function subtracaoNumeros(){

    let subtracaoNumeros = Number(numeroUm.value) - Number(numeroDois.value)
    subtracaoNumeros = subtracaoNumeros.toFixed(2)


    alert('O resultado é ' + subtracaoNumeros)
}

function multiplicacaoNumeros(){

    let multiplicacaoNumeros = Number(numeroUm.value) * Number(numeroDois.value)
    multiplicacaoNumeros = multiplicacaoNumeros.toFixed(2)

    alert('O resultado é ' + multiplicacaoNumeros)
}

function divisaoNumeros(){

    let divisaoNumeros = Number(numeroUm.value) / Number(numeroDois.value)
    divisaoNumeros = divisaoNumeros.toFixed(2)

    alert('O resultado é ' + divisaoNumeros)
}